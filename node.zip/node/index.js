/******************************************************************************
* ITE5315 – Project
* I declare that this assignment is my own work in accordance with Humber Academic Policy.
* No part of this assignment has been copied manually or electronically from any other source
* (including web sites) or distributed to other students.
*
* Group member Name: Smit Shah      Student IDs: N01580089  Date: 03/04/2024
*                    Vivek Jethva                N01579474        
******************************************************************************/

// Import necessary modules
const express = require("express"); // Express.js framework
const bodyParser = require("body-parser"); // Middleware to parse incoming request bodies
const exphbs = require("express-handlebars"); // Templating engine for Express
const path = require("path"); // Module for working with file and directory paths
const cors = require("cors"); // Middleware for enabling Cross-Origin Resource Sharing (CORS)
const session = require("express-session"); // Middleware for managing sessions
const crypto = require('crypto'); // Module for cryptographic functionality
const db = require("./config/database"); // Database configuration
const passport = require("passport"); // Passport configuration
const userRoutes = require("./routes/userRoutes"); // Routes for user-related endpoints
const adminRoutes = require("./routes/adminRoutes"); // Routes for admin-related endpoints
const restaurantRoutes = require("./routes/restaurantRoutes"); // Routes for restaurant-related endpoints
const handlebars = require("handlebars"); // Handlebars templating engine
const {
    allowInsecurePrototypeAccess,
} = require("@handlebars/allow-prototype-access");

const app = express(); // Initialize Express application

// Middleware
app.use(bodyParser.urlencoded({ extended: true })); // Parse application/x-www-form-urlencoded
app.use(bodyParser.json()); // Parse application/json
app.use(bodyParser.json({ type: "application/vnd.api+json" })); // Parse custom JSON types
app.use(express.static(path.join(__dirname, "public"))); // Serve static files from 'public' directory
app.use(cors()); // Enable CORS for all requests
// Configure the express-handlebars view engine with the '.hbs' file extension
app.engine('.hbs', exphbs.engine({
    extname: '.hbs',
    handlebars: allowInsecurePrototypeAccess(handlebars),
}));

// Set 'hbs' as the default view engine for the application
app.set('view engine', 'hbs');

// Wildcard route to allow user to be used in templates
// app.get("*", function (req, res, next) {
//     res.locals.user = req.user || null; // Set 'user' to null if not authenticated
//     next(); // Pass control to the next middleware
// });

// Define the port for the server
const PORT = process.env.PORT || 8000;

// Initialize session
app.use(session({
    secret: "secret", // Secret used to sign the session ID cookie
    resave: false,
    saveUninitialized: false,
    cookie: {}, // Session cookie settings
}));

// Passport config
require("./config/passport")(passport);

// MongoDB connection URL
const dbUrl = "mongodb+srv://SmitShahMongo:SmitShahMongo@cluster0.j5cbh1q.mongodb.net/sample_restaurants";

// Initialize MongoDB connection
db.initialize(dbUrl)
    .then(() => {

        // Set up routes
        app.use("/api/users", userRoutes); // User routes
        app.use("/api/admin", adminRoutes); // Admin routes
        app.use("/api/restaurants", restaurantRoutes); // Restaurant routes

        // Start the server after successfully connecting to MongoDB
        app.listen(PORT, () => {
            console.log(`Server is running on port ${PORT}`);
        });
    })
    .catch((err) => {
        console.error(`Failed to connect to MongoDB: ${err}`);
    });



// Route to render home page
app.get('/', function (req, res) {
    res.render('home', { title: 'Home Page' }); // Render 'home' view with title 'Home Page'
});


// // app.get('/home', function (req, res) {
// //     res.render('home', { title: 'Home Page' });
// // });

// // app.get('/login', function (req, res) {
// //     res.render('login', { title: 'Login' });
// // });

// // app.get('/register', function (req, res) {
// //     res.render('register', { title: 'Register' });
// // });

// // Listen on a port
// app.listen(PORT, () => console.log(`Server started on port ${PORT}`));
